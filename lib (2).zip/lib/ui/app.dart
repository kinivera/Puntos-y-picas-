import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants.dart';
import '../funcionalidad/game.dart';
import '../funcionalidad/juego.dart';
import 'pages/level.dart';
import 'pages/mode.dart';
import 'pages/results.dart';
import 'pages/solitario.dart';
import 'pages/versus.dart';
import 'pages/win.dart';
import 'pages/win2.dart';
import 'package:flex_color_scheme/flex_color_scheme.dart';
import 'package:google_fonts/google_fonts.dart';

class App extends StatelessWidget {
  const App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Parcial',

      theme: FlexThemeData.light(
        scheme: FlexScheme.damask,
        surfaceMode: FlexSurfaceMode.levelSurfacesLowScaffold,
        blendLevel: 4,
        subThemesData: const FlexSubThemesData(
          blendOnLevel: 10,
          blendOnColors: false,
          elevatedButtonRadius: 40.0,
          outlinedButtonBorderWidth: 2.5,
        ),
        textTheme: const TextTheme(
              bodyLarge: TextStyle(
                fontSize: 16.0,
              ),
            ),
        visualDensity: FlexColorScheme.comfortablePlatformDensity,
      ),

      initialRoute: MODE,
      getPages: [
        GetPage(name: MODE, page: () => Mode()),
        GetPage(name: LEVEL, page: () => Level()),
        GetPage(name: JUEGO, page: () => Juego()),
        GetPage(name: SOLITARIO, page: () => Solitario()),
        GetPage(name: VERSUS, page: () => Versus()),
        GetPage(name: WIN, page: () => Win()),
        GetPage(name: RESULTS, page: () => Results()),
        GetPage(name: WIN2, page: () => Win2()),
      ],
      initialBinding: BindingsBuilder(() {
      Get.lazyPut(() => GameController());
      }),
    );
  }
}
