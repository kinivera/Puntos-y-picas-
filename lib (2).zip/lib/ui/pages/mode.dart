import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constants.dart';
import '../../funcionalidad/game.dart';

class Mode extends StatefulWidget {
  const Mode({Key? key}) : super(key: key);

  @override
  _ModeState createState() => _ModeState();
}

class _ModeState extends State<Mode> {
  Widget build(BuildContext context) {
    GameController gameController = Get.find();

    return Scaffold(
      appBar: AppBar(
        title: Text("Mode"),
        actions: [
          IconButton(
            onPressed: () {
              Get.offNamed(MODE);
            },
            icon: Icon(Icons.logout),
          )
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/images/Fondo.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              childAspectRatio: 1,
              mainAxisSpacing: 10,
              padding: const EdgeInsets.all(10),
              shrinkWrap: true,
              physics: const ScrollPhysics(),
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.person, size: 80, color: Colors.deepOrange.shade300),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          gameController.GameMode(true);
                        });
                        Get.offNamed(LEVEL);
                      },
                      child: Text("Modo Solitario"),
                    ),
                  ],
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.people, size: 80, color: Colors.deepOrange.shade300),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          gameController.GameMode(false);
                        });
                        Get.offNamed(LEVEL);
                      },
                      child: Text("Modo Versus"),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
