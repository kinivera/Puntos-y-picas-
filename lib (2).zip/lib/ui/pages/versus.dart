import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constants.dart';
import '../../funcionalidad/game.dart';
import '../../funcionalidad/numbers.dart';


class Versus extends StatelessWidget {
  const Versus({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    GameController gameController = Get.find();
    
    return Scaffold(
      appBar: AppBar(
        title: const Text("Versus"),
        actions: [
          IconButton(
              onPressed: () {
                Get.offNamed(MODE);
              },
              icon: const Icon(Icons.logout))
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/images/Fondo.png"),
              fit: BoxFit.cover,
            ),
          ),
          constraints: const BoxConstraints.expand(),
        child: Column(
          children: [
            Text(
              "Seleccione los números:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Obx(() => gameController.selectednumbers.value.isNotEmpty ?  Text('${gameController.selectednumbers.value}',       
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                )
              : Container(),
            ),

                GridView.count(
                crossAxisCount: 5, // número de columnas
                crossAxisSpacing: 10,
                // especificamos cómo se deben ajustar los elementos del grid
                childAspectRatio: 1,
                mainAxisSpacing: 10, // espacio vertical entre filas
                padding: const EdgeInsets.all(10), // padding del grid
                shrinkWrap: true, // indica si el grid debe adaptarse al contenido
                physics: const ScrollPhysics(), // espacio entre las columnas
                children: Numbers(), // permite hacer scroll si es necesario
              ),
            ElevatedButton(onPressed: (){ gameController.resetselection();},
             child: Text("Repetir selección"),
             ),
            ElevatedButton(onPressed: (){ 
              gameController.verify();              
              },
             child: Text("Jugar"),
             ),
          ],
        ),
),

    );
  }
}
