import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constants.dart';
import '../../funcionalidad/game.dart';

class Win extends StatefulWidget {
  const Win({Key? key}) : super(key: key);


  @override
  _WinState createState() => _WinState();

}

class _WinState extends State<Win>{

  Widget build(BuildContext context) {
    GameController gameController = Get.find();

     
    return Scaffold(
      appBar: AppBar(
        title: Text("Win"),
        actions: [
          IconButton(
              onPressed: () {
                Get.offNamed(MODE);
              },
              icon: Icon(Icons.logout))
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/images/Fondo.png"),
              fit: BoxFit.cover,
            ),
          ),
          constraints: const BoxConstraints.expand(),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
                Image.asset(
                'assets/images/player2.png',
                width: 300,
                ),
            ElevatedButton(
                onPressed: () {
                  setState(() {
                    gameController.GameMode(false);
                  });
                  Get.offNamed(VERSUS);
                },
                child: Text("Jugar")),
          ],
        ),
      ),
    );
  }
}


