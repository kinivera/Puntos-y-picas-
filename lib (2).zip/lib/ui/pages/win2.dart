import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constants.dart';
import '../../funcionalidad/game.dart';

class Win2 extends StatefulWidget {
  const Win2({Key? key}) : super(key: key);


  @override
  _Win2State createState() => _Win2State();

}

class _Win2State extends State<Win2>{

  Widget build(BuildContext context) {
    GameController gameController = Get.find();

     
    return Scaffold(
      appBar: AppBar(
        title: Text("Results"),
        actions: [
          IconButton(
              onPressed: () {
                Get.offNamed(MODE);
                gameController.gameover();
              },
              icon: Icon(Icons.notification_important))
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/images/Fondo.png"),
              fit: BoxFit.cover,
            ),
          ),
          constraints: const BoxConstraints.expand(),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Image.asset(
                'assets/images/gameover.png',
                width: 500,
                ),
          Obx(
          () => Column(
            children: [
                    Image.asset(
                    'assets/images/player1.png',
                    width: 300,
                    ),
              Text(
                'Tuviste: ${gameController.attempsp1} intentos',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),

        ],
      ),
    ),

          ],
        ),
      ),
    );
  }
}


