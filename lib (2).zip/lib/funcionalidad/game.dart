
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants.dart';
import 'dart:math';



class GameController extends GetxController{
  var solitario = true.obs;
  var facil = false.obs;
  var normal = false.obs;
  var dificil = false.obs;
  var player1 = true.obs;
  var player2 = false.obs;
  RxInt attempsp1 = 0.obs;
  RxInt attempsp2 = 0.obs;
  RxInt puntos = 0.obs;
  RxInt picas = 0.obs;
  RxList selectednumbers= [].obs;
  RxList guessnumbers= [].obs;
  RxList list = [].obs;
  

// seleccion de modo
  void GameMode(bool solo){
    solitario.value = solo;
    if (solitario.value) {
      print("solitario");
    }
    else{
      print("versus");
    }
  }

// seleccion dificultad
  void prueba(){
    if (facil.value==true) {
      print("facil");
    }
    if (normal.value==true) {
      print("normal");
    }
    if (dificil.value==true) {
      print("dificil");
    }
  }

  void resetselection(){
    selectednumbers.value = [];
  
  }

  void verify(){
    bool error =false;
    for (var i = 0; i < selectednumbers.length; i++) {
      for (var j = i+1; j < selectednumbers.length; j++) {
        if (selectednumbers[i]==selectednumbers[j]) {
          //print('${selectednumbers[i]};${i},${selectednumbers[j]};${j},');
          //print('${selectednumbers}');
          error=true;
        }
      }
      }
      if (error==true || selectednumbers.length < 3) {
        Get.snackbar('Error', 'Los números deben ser distintos',
                            icon: Icon(Icons.error_outline),
                            backgroundColor: Color.fromARGB(255, 255, 110, 99));
      }else{
        Get.offNamed(JUEGO);
      
    }
  }

  void reguess(){
    guessnumbers.value = [];
  }

  void points(){
    picas.value=0;
    puntos.value=0;
  }




   void playagain(){
    reguess();
    points();
  }

    void puntosypicas(){
      if (player1==true) {
        attempsp1=++attempsp1;
        print('player1');
      }
      if (player2==true) {
        attempsp2=++attempsp2;
        print('player2');
      }
      for (var i = 0; i < selectednumbers.length; i++) {
      for (var j = 0; j < guessnumbers.length; j++) {
        if (selectednumbers[i]==guessnumbers[j]) {
          puntos = ++puntos;
        }
        if (selectednumbers[i]==guessnumbers[j] && i==j) {
          picas = ++picas;
        }
        
      }
      
    }

    if (selectednumbers.length == guessnumbers.length && selectednumbers.every((element) => guessnumbers.contains(element))) {
        player2.value=true;
        player1.value=false;
        print(player1);
        print(player2);
        print(attempsp1);
        print(attempsp2);
        if (attempsp1.value!=0 && attempsp2.value!=0 &&  player2.value==true) {
          resetselection();
          reguess();
          points();
          Get.offNamed(RESULTS);
        }
        if (facil.value==true && picas.value==3 && puntos.value==3 && player1.value==false ) {
          print('si');
          resetselection();
          reguess();
          points();
          Get.offNamed(WIN);
        }else if (normal.value==true && picas.value==4 && puntos.value==4 && player1.value==false) {
          resetselection();
          reguess();
          points();
          Get.offNamed(WIN);
        }else if (dificil.value==true && picas.value==5 && puntos.value==5 && player1.value==false) {
          resetselection();
          reguess();
          points();
          Get.offNamed(WIN);
        }      
    }
  }

  void solo(){
    attempsp1=++attempsp1;
    print(list);
    for (var i = 0; i < list.length; i++) {
      for (var j = 0; j < guessnumbers.length; j++) {
        if (list[i]==guessnumbers[j]) {
          puntos = ++puntos;
        }
        if (list[i]==guessnumbers[j] && i==j) {
          picas = ++picas;
        }
      } 
    }
    if (list.length == guessnumbers.length && list.every((element) => guessnumbers.contains(element))) {
      Get.offNamed(WIN2);  
    }

  }

  void gameover(){
    attempsp1.value=0;
    attempsp2.value=0;
    reguess();
    player2.value=false;
    player1.value=true;
  }

  

  List random(){
    int length=0;
    if (facil.value==true) {
      length=3;
    }else if(normal.value==true){
      length=4;
    }else if(dificil.value==true){
      length=5;
    } 

  Random random = Random();
  
  while (list.length < length) {
    int randomNumber = random.nextInt(10);
    if (!list.contains(randomNumber)) {
      list.add(randomNumber);
    }
  }
  return list; 
  }
  
}




