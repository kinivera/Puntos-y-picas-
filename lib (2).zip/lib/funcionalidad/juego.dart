import 'package:flutter/material.dart';
import 'package:get/get.dart';
//import 'package:named_getx_navigation/funcionalidad/guessnumbers.dart';
import 'package:parcial/funcionalidad/guessnumbers.dart';
import '../constants.dart';
import '../../funcionalidad/game.dart';
import '../../funcionalidad/numbers.dart';


class Juego extends StatelessWidget {
  const Juego({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    GameController gameController = Get.find();

  return Scaffold(
    appBar: AppBar(
      title: Text("Puntos y picas "),
      actions: [
        IconButton(
          onPressed: () {
            Get.offNamed(MODE);
          },
          icon: Icon(Icons.logout),
        ),
      ],
    ),
    body: Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage("assets/images/Fondo.png"),
          fit: BoxFit.cover,
        ),
      ),
      constraints: const BoxConstraints.expand(),
      child: Column(
        children: [
          Text(
            "Seleccione los números que cree eligió el jugador ${gameController.player1.value ? '2' : '1'}:",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Obx(() => gameController.guessnumbers.value.isNotEmpty ?  Text('${gameController.guessnumbers.value}',       
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                )
              : Container(),
            ),
          GridView.count(
            crossAxisCount: 5,
            crossAxisSpacing: 10,
            childAspectRatio: 1,
            mainAxisSpacing: 10,
            padding: const EdgeInsets.all(10),
            shrinkWrap: true,
            physics: const ScrollPhysics(),
            children: guessNumbers(),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: [
                  Icon(Icons.radio_button_checked, size: 50),
                  SizedBox(height: 10),
                  Obx(
                    () => Text(
                      'Tienes ${gameController.puntos} puntos',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  Icon(Icons.my_location, size: 50),
                  SizedBox(height: 10),
                  Obx(
                    () => Text(
                      'Tienes ${gameController.picas} picas',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  Icon(Icons.precision_manufacturing, size: 50),
                  SizedBox(height: 10),
                  Obx(
                    () => Text(
                      'Tienes ${gameController.player1.value ? gameController.attempsp1 : gameController.attempsp2} intentos',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                onPressed: () {
                  gameController.playagain();
                },
                child: Text("Repetir selección"),
              ),
              SizedBox(width: 20),
              ElevatedButton(
                onPressed: () {
                  gameController.puntosypicas();
                },
                child: Text("Comprobar"),
              ),
            ],
          ),

          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 4.0,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Recuerda que un punto se da por cada dígito que está en el número, pero no en la posición exacta  y una fama se da por cada dígito que está en el número, en la posición exacta',
                style: TextStyle(fontSize: 18.0),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
}