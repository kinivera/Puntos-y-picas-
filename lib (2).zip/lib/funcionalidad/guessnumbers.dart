import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'game.dart';

List<Widget> guessNumbers() {
  GameController gameController = Get.find();
  List<Widget> num = [];

  for (int i = 0; i < 10; i++) {
    num.add(ElevatedButton(
      onPressed: () {
        if (gameController.facil.value==true) {
          if (gameController.guessnumbers.length<3) {
            gameController.guessnumbers.add(i);
            print("a");
            print(gameController.guessnumbers.length<3);
            print(gameController.guessnumbers);
          }
          
        } else if (gameController.normal.value==true) {
           if (gameController.guessnumbers.length<4) {
              gameController.guessnumbers.add(i);
              print("b");
              print(gameController.guessnumbers.length<4);
            print(gameController.guessnumbers);
            }
              
         } else if (gameController.dificil.value==true){
            if (gameController.guessnumbers.length<5) {
              gameController.guessnumbers.add(i);
              print("c");
              print(gameController.guessnumbers.length<5);
            print(gameController.guessnumbers);
              }
              
            }
          },
          child: Text(i.toString()),
        ));
      }
    return num;
    } 
