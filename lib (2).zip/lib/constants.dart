// routes

const MODE = '/mode';
const LEVEL = '/level';
const SOLITARIO = '/solitario';
const VERSUS = '/versus';
const JUEGO = '/juego';
const WIN = '/win';
const RESULTS = '/results';
const WIN2 = '/win2';